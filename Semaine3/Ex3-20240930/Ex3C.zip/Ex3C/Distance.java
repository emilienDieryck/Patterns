public interface Distance { 
	String getDistance();
}
