public interface BattleShip {

  void fire();

  void move(Distance distance);

}
