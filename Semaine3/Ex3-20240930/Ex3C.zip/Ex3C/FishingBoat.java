public class FishingBoat {

  public void sail(Distance distance) {
    System.out.println("The Boat is moving "+distance.getDistance());
  }

  public void fish() {
	  System.out.println("fishing ...");
  }

}
