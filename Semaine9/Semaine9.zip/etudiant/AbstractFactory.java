
public interface AbstractFactory {

    public Robot createRobot();

}
