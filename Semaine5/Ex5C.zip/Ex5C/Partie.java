public interface Partie {
	void demande(Traitement traitement);

	int getNiveau();
}
