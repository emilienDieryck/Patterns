public interface Traitement {
	void traiteValeur(Valeur unique);

	void traiteGroupe(Groupe plusieurs);
}
